﻿using System;

namespace SuperDamp.Models
{
    internal class keyAttribute : Attribute
    {
    }
}